package com.cognizant.spring_core_xml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreXmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
