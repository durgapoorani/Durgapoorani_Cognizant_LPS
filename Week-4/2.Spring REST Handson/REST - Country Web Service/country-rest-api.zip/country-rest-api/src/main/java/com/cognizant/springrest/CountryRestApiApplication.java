package com.cognizant.springrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryRestApiApplication.class, args);
	}

}
