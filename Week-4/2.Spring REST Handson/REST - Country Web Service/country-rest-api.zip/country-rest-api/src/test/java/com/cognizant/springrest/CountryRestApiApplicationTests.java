package com.cognizant.springrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
