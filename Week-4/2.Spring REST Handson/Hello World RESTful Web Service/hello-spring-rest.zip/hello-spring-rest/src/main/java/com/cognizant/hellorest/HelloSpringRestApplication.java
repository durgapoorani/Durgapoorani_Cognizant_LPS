package com.cognizant.hellorest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringRestApplication.class, args);
	}

}
