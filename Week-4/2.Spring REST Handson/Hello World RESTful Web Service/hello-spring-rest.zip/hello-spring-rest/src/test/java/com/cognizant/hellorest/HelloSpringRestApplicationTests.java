package com.cognizant.hellorest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
