package com.library.LibraryManagementEx9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementEx9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
